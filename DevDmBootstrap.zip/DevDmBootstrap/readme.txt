## DevDmBootstrap

This is a responsive Twitter Bootstrap WordPress Theme built on Twitter Bootstrap 2.3.2. I've been sitting on this for far too long and came to the realization nothing is perfect. With the Release of Bootstrap 3 RC1 this seems old hat now. But I don't want my work to go to waste.

A lot of folks have been saying that there isn't a good theme out there for developers. Most themes are trying to cater to the average joe. They are all full of bloated short codes and frameworks that make zero sense. This is my answer to that. So if you don't know how WordPress works and you try to use this, "You might have a bad time"

### Documentation / Demo (in progress)

http://devdm.com/DevDmBootstrap/

**The DevDm Blog is now using a CHILD-Theme of DevDmBootstrap just to show you what is possible.**
http://devdm.com/blog/

